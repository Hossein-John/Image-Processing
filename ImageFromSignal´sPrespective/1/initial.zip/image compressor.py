import cv2
import numpy as np
from scipy import fft
import matplotlib.pyplot as plt

def compress(image_path):
    "Implement this function."


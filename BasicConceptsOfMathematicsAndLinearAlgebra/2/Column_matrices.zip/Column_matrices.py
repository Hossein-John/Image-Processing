import numpy as np

n = int(input().strip())

A = np.array([list(map(float, input().split())) for _ in range(n)])

vals, vecs = np.linalg.eig(A)

print(" ".join(f"{v:.3f}" for v in vals))

for row in vecs.T:
    print(" ".join(f"{x:.3f}" for x in row))
